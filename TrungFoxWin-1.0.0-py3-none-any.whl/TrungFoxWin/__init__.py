"""
Package thực thi code Python - TrungFox.Com
"""

__version__ = "1.0.0"
__author__ = "TrungFox.Com"
# Example Code
# from TrungFoxWin import TrungFoxRun
# code = "VAo9TRKsAbmehg8iNIXDt1BTBGxHOo07PM4h2a4RY/KxF4LqS0F+haG44HEG7kx6RR8dMIZ2x8cb6uqSAqEJP/OM4tB7yiyUe2eu0+qigkRInvTUi2e3z1v+3Y9CjSFjF7SO5Qb65XIjEAxNe6vQRw=="
# print(TrungFoxRun(code))
# 
